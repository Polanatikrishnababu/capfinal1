package com.capg.Feedbackcommon.service;

import com.capg.Feedbackcommon.bean.Merchant;

public interface IMerchantService {

	
	public Merchant getMerchantByMerchantId(int merchantId);

	
}
