package com.capg.Feedbackcommon.service;

import java.util.List;

import com.capg.Feedbackcommon.bean.Customer;

public interface ICustomerService {

	

	
	
	
	public Customer getCustomerByCustomerId(int customerId);
	



	
	
}
