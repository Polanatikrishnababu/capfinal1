package com.capg.Feedbackcommon.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capg.Feedbackcommon.bean.Customer;

@Repository("customerDao")
@Transactional
public interface ICustomerDao extends JpaRepository<Customer,Integer> {


	

	@Query("from Customer where customer_id=:customerId")
	Customer getByCustomer(@Param("customerId") Integer custId);
	
	
//	public List<Customer> getAllCustomers();



}
