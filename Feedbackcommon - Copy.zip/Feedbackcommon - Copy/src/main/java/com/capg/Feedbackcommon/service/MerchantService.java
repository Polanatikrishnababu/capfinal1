package com.capg.Feedbackcommon.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.Feedbackcommon.bean.Merchant;
import com.capg.Feedbackcommon.dao.IMerchantDao;




@Service("merchantService")
public class MerchantService implements IMerchantService{

	@Autowired
	IMerchantDao merchantDao;
	
	@Autowired
	public FeedbackService feedbackService;

	


	@Override
	public Merchant getMerchantByMerchantId(int merchantId) {
		Optional<Merchant> optional = merchantDao.findById(merchantId);
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}
	
}
