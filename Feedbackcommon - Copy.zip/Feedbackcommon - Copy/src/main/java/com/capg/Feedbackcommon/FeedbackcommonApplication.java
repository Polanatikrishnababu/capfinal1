package com.capg.Feedbackcommon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackcommonApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbackcommonApplication.class, args);
	}

}
